#ifndef __c_fcntl_h
#define __c_fcntl_h

#include <fcntl.h>

#endif

/* end of c_fcntl.h */

